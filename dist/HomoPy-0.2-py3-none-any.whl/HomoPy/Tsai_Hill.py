# -*- coding: utf-8 -*-
"""
Created on Tue Apr 26 21:24:30 2022

@author: chri

Modified Tsai-Hill Criterion after Yan, Yang et al. (2018)
"""

import numpy as np
